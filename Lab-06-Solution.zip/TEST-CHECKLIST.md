# Lab 06 test checklist

Record **Pass** or **Fix** after testing the application locally.

| Test | Expected result |
|---|---|
| Open `/dashboard` while logged out | Redirect to login |
| Register valid, new details | One new user; login page shows success |
| Register an email that already exists | Validation error; no additional user |
| Use a short password | Validation fails; no account created |
| Use mismatched password confirmation | Validation fails; no account created |
| Log in with correct details | Dashboard shows current user's name and email |
| Log in with incorrect password | Error message; dashboard remains protected |
| Open `/login` while already logged in | Guest middleware redirects away from login |
| Log out and request `/dashboard` again | Redirect to login |
| Log in as a second test account | Dashboard shows second account's details |
