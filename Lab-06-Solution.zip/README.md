# IT Student Portal — Laravel 12 Authentication Lab

This solution completes the tasks in `Lab-06.pdf`: registration, login, protected dashboard, logout, and test checklist.

## Requirements
- PHP 8.2+
- Composer
- MySQL
- Laravel 12 project

## Install / setup
1. Create the Laravel 12 project:
   ```bash
   composer create-project laravel/laravel it-auth-lab "^12.0"
   cd it-auth-lab
   ```
2. Create an empty MySQL database named `it_auth_lab` in phpMyAdmin.
3. Copy the provided `.env.example.lab` settings into your project's `.env` (or edit the corresponding DB settings).
4. Copy the files/folders in this ZIP into the matching locations in your Laravel project, overwriting `routes/web.php` and adding the view/controller files.
5. Run:
   ```bash
   php artisan config:clear
   php artisan migrate
   php artisan route:list
   php artisan serve
   ```
6. Open `http://127.0.0.1:8000`.

## Test
- Visit `/dashboard` while logged out: it should redirect to `/login`.
- Register a new account using a unique email and a password of at least 8 characters.
- Log in and check that the dashboard displays the account name and email.
- Log out, then revisit `/dashboard`: access should be blocked.
- Try duplicate email, short password, mismatched confirmation, and incorrect login to verify validation/errors.

## Short answers for instructor
1. `Hash::make()` hashes a password before saving it, so the plain-text password is not stored in the database.
2. The `auth` middleware allows only authenticated users to access the dashboard route; guests are redirected to login.
3. `@csrf` inserts a CSRF token into the form so Laravel can verify that the POST request came from a valid session/form.

## Notes
- This ZIP contains the lab files to copy into a fresh Laravel 12 project; it is not a full Laravel framework installation.
- The database credentials in `.env.example.lab` are common local defaults only. Change them if your MySQL setup differs.
